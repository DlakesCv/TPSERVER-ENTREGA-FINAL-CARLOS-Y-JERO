#!/bin/bash
# este codigo lo hice con chat gpt , aunque la estructura la modifique un poco ya que se me hiso similar a phyton
# Modo de uso
if [[ "$1" == "-help" || $# -lt 2 ]]; then
  echo "Uso: $0 origen destino"
  echo "Ejemplo: $0 /var/log /backup_dir"
  exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

# Verificar directorios
if [ ! -d "$ORIGEN" ]; then
  echo "Error: el directorio de origen no existe."
  exit 1
fi

if [ ! -d "$DESTINO" ]; then
  echo "Error: el directorio de destino no existe."
  exit 1
fi

# Crear archivo de backup
NOMBRE=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"

if [ $? -eq 0 ]; then
  echo "Backup completado: $DESTINO/$NOMBRE"
else
  echo "Error durante el backup."
fi
